#include <iostream>
#include <stdint.h>

#define KYBER_Q 3329       //q representing MOD
#define R  65535          // 2^16
#define MONT 2285        // 2^16 mod q =2285  used to compute zetas and inv zetas in NT domain (Not used)
                        //In this code, used already computed zetas to increase computational speed
#define QINV 62209     // q^-1 mod 2^16
#define KYBER_K 1     //  define security strength for kyber 512 (with 256 coefficients)
#define KYBER_N 256  //polynomial length and amount of coefficients


/*
 * Elements of R_3329 = Z_3329[X]/(X^256 + 1). Represented By polynomial
 * coeffs[0] + X*coeffs[1] + X^2*xoeffs[2] + ... + X^{256}*coeffs[256]
 */

typedef struct{
    int16_t coeffs[KYBER_N];
} poly;


typedef struct{
    poly vec[KYBER_K];
} polyvec;


/*************************************************
* Name:        montgomery_reduce
*
* Description: Montgomery reduction; given a 32-bit integer a, computes
*              16-bit integer congruent to a * R^-1 mod q,
*              where R=2^16
*
* Arguments:   - int32_t a: input integer to be reduced;
*                           has to be in {-q2^15,...,q2^15-1}
*
* Returns:     integer in {-q+1,...,q-1} congruent to a * R^-1 modulo q.
**************************************************/
int16_t montgomery_reduce(int32_t a)
{
    int32_t t;
    int16_t u;

    u = (int16_t) a*QINV;
    t = (int32_t)u*KYBER_Q;
    t = a - t;
    t >>= 16;
    return (int16_t) t;
}

/*************************************************
* Name:        barrett_reduce
*
* Description: Barrett reduction; given a 16-bit integer a, computes
*              16-bit integer congruent to a mod q in {0,...,q}
*
* Arguments:   - int16_t a: input integer to be reduced
*
* Returns:     integer in {0,...,q} congruent to a modulo q.
**************************************************/
int16_t barrett_reduce(int16_t a) {
    int16_t t;
    const int16_t v = ((1U << 26) + KYBER_Q/2)/KYBER_Q;

    t  = (int32_t)v*a >> 26;
    t *= KYBER_Q;
    return a - t;
}

const int16_t zetas[128] = {
        2285, 2571, 2970, 1812, 1493, 1422,  287, 202,  3158,  622, 1577,  182,  962, 2127, 1855, 1468,
        573, 2004,  264,  383, 2500, 1458, 1727, 3199, 2648, 1017,  732,  608, 1787,  411, 3124, 1758,
        1223,  652, 2777, 1015, 2036, 1491, 3047, 1785,  516, 3321, 3009, 2663, 1711, 2167,  126, 1469,
        2476, 3239, 3058,  830,  107, 1908, 3082, 2378, 2931,  961, 1821, 2604,  448, 2264,  677, 2054,
        2226,  430,  555,  843, 2078,  871, 1550,  105,  422,  587,  177, 3094, 3038, 2869, 1574, 1653,
        3083,  778, 1159, 3182, 2552, 1483, 2727, 1119, 1739,  644, 2457,  349,  418,  329, 3173, 3254,
        817, 1097,  603,  610, 1322, 2044, 1864, 384, 2114, 3193,  1218, 1994, 2455,  220, 2142, 1670,
        2144, 1799, 2051,  794, 1819, 2475, 2459, 478, 3221, 3021,   996,  991,  958, 1869, 1522, 1628
};

const int16_t zetas_inv[128] = {
        1701, 1807, 1460, 2371, 2338, 2333,   308,  108, 2851,  870,  854, 1510, 2535, 1278, 1530, 1185,
        1659, 1187, 3109,  874, 1335, 2111,   136, 1215, 2945, 1465, 1285, 2007, 2719, 2726, 2232, 2512,
        75,  156, 3000, 2911, 2980,  872,  2685, 1590, 2210,  602, 1846,  777,  147, 2170, 2551,  246,
        1676, 1755,  460,  291,  235, 3152,  2742, 2907, 3224, 1779, 2458, 1251, 2486, 2774, 2899, 1103,
        1275, 2652, 1065, 2881,  725, 1508,  2368,  398,  951,  247, 1421, 3222, 2499,  271,    90, 853,
        1860, 3203, 1162, 1618,  666,  320,     8, 2813, 1544,  282, 1838, 1293, 2314,  552,  2677, 2106,
        1571,  205, 2918, 1542, 2721, 2597,  2312,  681,  130, 1602, 1871,  829, 2946, 3065,  1325, 2756,
        1861, 1474, 1202, 2367, 3147, 1752,  2707,  171, 3127, 3042, 1907, 1836, 1517,  359,   758, 1441
};

/*************************************************
* Name:        fqmul
*
* Description: Multiplication followed by Montgomery reduction
*
* Arguments:   - int16_t a: first factor
*              - int16_t b: second factor
*
* Returns 16-bit integer congruent to a*b*R^{-1} mod q
**************************************************/
static int16_t fqmul(int16_t a, int16_t b) {
    return montgomery_reduce((int32_t)a*b);
}


/*************************************************
* Name:        poly_reduce
*
* Description: Applies Barrett reduction to all coefficients of a polynomial
*              for details of the Barrett reduction see comments in reduce.c
*
* Arguments:   - poly *r: pointer to input/output polynomial
**************************************************/
void poly_reduce(poly *r)
{
    unsigned int i;
    for(i=0;i<KYBER_N;i++) {
        r->coeffs[i] = barrett_reduce(r->coeffs[i]);
        std::cout << r->coeffs[i] << " ";
    }

}


/*************************************************
* Name:        ntt
*
* Description: Inplace number-theoretic transform (NTT) in Rq
*              input is in standard order, output is in bitreversed order
*
* Arguments:   - int16_t r[256]: pointer to input/output vector of elements
*                                of Zq
**************************************************/
void ntt(int16_t r[256]) {
    unsigned int len, start, j, k;
    int16_t t, zeta;

    k = 1;
    for (len = 128; len >= 2; len >>= 1) {
        for (start = 0; start < 256; start = j + len) {
            zeta = zetas[k++];
            for (j = start; j < start + len; ++j) {
                t = fqmul(zeta, r[j + len]);
                r[j + len] = r[j] - t;
                r[j] = r[j] + t;
            }
        }
    }
}

/*************************************************
* Name:        poly_ntt
*
* Description: Computes negacyclic number-theoretic transform (NTT) of
*              a polynomial in place;
*              inputs assumed to be in normal order, output in bitreversed order
*
* Arguments:   - uint16_t *r: pointer to in/output polynomial
**************************************************/
void poly_ntt(poly *r)
{
   ntt(r->coeffs);
   poly_reduce(r);
}

void polyvec_ntt(polyvec *r)
{
   int i;
    for(i=0;i<KYBER_K;i++)
        poly_ntt(&r->vec[i]);
}

/*************************************************
* Name:        invntt_tomont
*
* Description: Inplace inverse number-theoretic transform in Rq and
*              multiplication by Montgomery factor 2^16.
*              Input is in bitreversed order, output is in standard order
*
* Arguments:   - int16_t r[256]: pointer to input/output vector of elements
*                                of Zq
**************************************************/
void invntt(int16_t r[256]) {
    unsigned int start, len, j, k;
    int16_t t, zeta;
    k = 0;
    for(len = 2; len <= 128; len <<= 1) {
        for(start = 0; start < 256; start = j + len) {
            zeta = zetas_inv[k++];
            for(j = start; j < start + len; ++j) {
                t = r[j];
                r[j] = barrett_reduce(t + r[j + len]);
                r[j + len] = t - r[j + len];
                r[j + len] = fqmul(zeta, r[j + len]);
            }
        }
    }
    for(j = 0; j < 256; ++j){
        r[j] =fqmul(r[j] ,zetas_inv[127]);
    }
}

/*************************************************
* Name:        poly_invntt_tomont
*
* Description: Computes inverse of negacyclic number-theoretic transform (NTT)
*              of a polynomial in place;
*              inputs assumed to be in bitreversed order, output in normal order
*
* Arguments:   - uint16_t *a: pointer to in/output polynomial
**************************************************/
void poly_invntt(poly *r)
{
    invntt(r->coeffs);
    poly_reduce(r);
}

/*************************************************
* Name:        basemul
*
* Description: Multiplication of polynomials in Zq[X]/(X^2-zeta)
*              used for multiplication of elements in Rq in NTT domain
*
* Arguments:   - int16_t r[2]:       pointer to the output polynomial
*              - const int16_t a[2]: pointer to the first factor
*              - const int16_t b[2]: pointer to the second factor
*              - int16_t zeta:       integer defining the reduction polynomial
**************************************************/
void basemul(int16_t r[2],
             const int16_t a[2],
             const int16_t b[2],
             int16_t zeta)
{
    r[0]  = fqmul(a[1], b[1]);
    r[0]  = fqmul(r[0], zeta);
    r[0] += fqmul(a[0], b[0]);
    r[0]= barrett_reduce(r[0]);

    r[1]  = fqmul(a[0], b[1]);
    r[1] += fqmul(a[1], b[0]);
    r[1]= barrett_reduce(r[1]);
}

/*************************************************
* Name:        poly_basemul_montgomery
*
* Description: Multiplication of two polynomials in NTT domain
*
* Arguments:   - poly *r:       pointer to output polynomial
*              - const poly *a: pointer to first input polynomial
*              - const poly *b: pointer to second input polynomial
**************************************************/
void poly_basemul_montgomery(poly *r, const poly *a, const poly *b)
{
    unsigned int i;
    for(i=0;i<KYBER_N/4;i++) {
        basemul(&r->coeffs[4*i], &a->coeffs[4*i], &b->coeffs[4*i], zetas[64+i]);
        basemul(&r->coeffs[4*i+2], &a->coeffs[4*i+2], &b->coeffs[4*i+2],-zetas[64+i]);
    }
}


void poly_add(poly *r, const poly *a, const poly *b)
{
    unsigned int i;
    for(i=0;i<KYBER_N;i++){
        r->coeffs[i] = a->coeffs[i] + b->coeffs[i];
    std::cout<<r->coeffs[i];}

}

/*************************************************
* Name:        polyvec_pointwise_acc_montgomery
*
* Description: Pointwise multiply elements of a and b, accumulate into r,
*              and multiply by 2^-16.
*
* Arguments: - poly *r:          pointer to output polynomial
*            - const polyvec *a: pointer to first input vector of polynomials
*            - const polyvec *b: pointer to second input vector of polynomials
**************************************************/

void polyvec_pointwise_acc_montgomery(poly *r,
const     polyvec *a,
const    polyvec *b)
{
unsigned int i;
poly t;
poly_basemul_montgomery(r, &a->vec[0], &b->vec[0]);
  poly_reduce(r);

}

int main() {
    polyvec poly_A[256]=
            {1344, 3325, 1821,  2175,  2841,   562,  2452,  1304,  3126,  3297,  193, 1281, 1726, 1865, 2920, 1688,  917, 1862, 1667, 2431,  776, 990,
             2842, 1060,  423,  2312,  2337,  2613,  3086,  3238,  1093,  2089, 3235,  573, 1923,  406, 1135, 1047, 2698,  932, 2003, 2891, 3201, 400,
             2415, 452,  3077,     3,  3302,  1415,    94,   749,    65,  2936, 1810,  488, 2907, 1806, 3101,  323, 1715,  865, 2413, 1621, 2427, 1995,
             233,  701,  2384,  2154,   364,  2934,  2026,   764,  2021,   137, 1500, 3012,  111,  575,  765,  860,  640,  372,  329, 2116, 3280, 2135,
             274,  522,   412,   346,  3131,  2839,     1,  2818,   732,   702, 2861,  545, 1066, 2467,  230, 2819, 2147,  368, 1978, 2818,  479, 212,
             1840, 1615, 2657,   627,  2554,  1463,   174,   488,  2973,   587,  834, 2776, 1085, 1823, 3253, 2805,  185,  444,   21, 2239,  570, 252,
             2717, 1608, 1367,  3195,  2087,  2567,   121,  2073,  1079,  1736, 1401, 1706,  962,  524, 1881, 2438, 1156,  127,  931, 1591, 2200, 2755,
             1515, 1677, 2940,  2948,  2686,  1850,   189,  2938,  2227,  2907, 2205,  265,  432, 1951, 2832,  553,  696, 1570, 3277, 2097, 3277, 1898,
             280,  2817, 1007,  1437,   603,  1939,  3028,  2803,  1365,  2203, 1151, 1964, 1822, 1497, 1473, 2011, 1106,  371, 2577, 3312, 1624, 3009,
             1934, 2116, 1221,   289,   357,  1170,    46,  1293,   727,   326, 1769, 1735, 2751, 2372, 1333,  110, 1847,  357, 2313,  657, 2321, 1794,
             1453, 1464,  920,  2813,   713,  1891,  2096,  1381,  1484,  1871,  262, 1774, 2229, 2420, 1820, 1181, 3147, 3134, 2951, 2541, 2557, 2982,
             545,  2667, 1500,   902,  2639,  3146,   882,  1104,  2327,  2717,  255, 1888, 3015, 2154,
              };


    polyvec poly_B[256]=
            {1344, 3325, 1821,  2175,  2841,   562,  2452,  1304,  3126,  3297,  193, 1281, 1726, 1865, 2920, 1688,  917, 1862, 1667, 2431,  776, 990,
             2842, 1060,  423,  2312,  2337,  2613,  3086,  3238,  1093,  2089, 3235,  573, 1923,  406, 1135, 1047, 2698,  932, 2003, 2891, 3201, 400,
             2415, 452,  3077,     3,  3302,  1415,    94,   749,    65,  2936, 1810,  488, 2907, 1806, 3101,  323, 1715,  865, 2413, 1621, 2427, 1995,
             233,  701,  2384,  2154,   364,  2934,  2026,   764,  2021,   137, 1500, 3012,  111,  575,  765,  860,  640,  372,  329, 2116, 3280, 2135,
             274,  522,   412,   346,  3131,  2839,     1,  2818,   732,   702, 2861,  545, 1066, 2467,  230, 2819, 2147,  368, 1978, 2818,  479, 212,
             1840, 1615, 2657,   627,  2554,  1463,   174,   488,  2973,   587,  834, 2776, 1085, 1823, 3253, 2805,  185,  444,   21, 2239,  570, 252,
             2717, 1608, 1367,  3195,  2087,  2567,   121,  2073,  1079,  1736, 1401, 1706,  962,  524, 1881, 2438, 1156,  127,  931, 1591, 2200, 2755,
             1515, 1677, 2940,  2948,  2686,  1850,   189,  2938,  2227,  2907, 2205,  265,  432, 1951, 2832,  553,  696, 1570, 3277, 2097, 3277, 1898,
             280,  2817, 1007,  1437,   603,  1939,  3028,  2803,  1365,  2203, 1151, 1964, 1822, 1497, 1473, 2011, 1106,  371, 2577, 3312, 1624, 3009,
             1934, 2116, 1221,   289,   357,  1170,    46,  1293,   727,   326, 1769, 1735, 2751, 2372, 1333,  110, 1847,  357, 2313,  657, 2321, 1794,
             1453, 1464,  920,  2813,   713,  1891,  2096,  1381,  1484,  1871,  262, 1774, 2229, 2420, 1820, 1181, 3147, 3134, 2951, 2541, 2557, 2982,
             545,  2667, 1500,   902,  2639,  3146,   882,  1104,  2327,  2717,  255, 1888, 3015, 2154};

    std::cout<<" \n\n";
    std::cout<<"NTT of Vector A: \n";
    polyvec_ntt(poly_A);

    std::cout<<" \n\n";
    std::cout<<" NTT of Vector B: \n";
    polyvec_ntt(poly_B);

    poly mp;
    std::cout<<" \n\n";
    std::cout<<" point wise multiplication of NTT(A) o NTT(B) : \n";
    polyvec_pointwise_acc_montgomery(&mp, poly_A, poly_B);

    std::cout<<" \n\n";
    std::cout<<" NTT^-1 [NTT(A) o NTT(B)]: \n";
    poly_invntt(&mp);
    return 0;
}

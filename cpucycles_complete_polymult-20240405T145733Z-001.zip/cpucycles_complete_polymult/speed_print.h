//
// Created by focal on 8/2/22.
//

#ifndef SPEED_PRINT_H
#define SPEED_PRINT_H



#include <stddef.h>
#include <stdint.h>

void print_results(const char *s, uint64_t *t, size_t tlen);


#endif SPEED_PRINT_H

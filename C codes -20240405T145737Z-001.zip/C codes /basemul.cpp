#include <stdint.h>
#define KYBER_Q 3329
#define QINV 62209
#define KYBER_N 256

typedef struct{
    int16_t coeffs[KYBER_N];
} poly;
const int16_t zetas[128] = {
        2285, 2571, 2970, 1812, 1493, 1422,  287, 202,  3158,  622, 1577,  182,  962, 2127, 1855, 1468,
        573, 2004,  264,  383, 2500, 1458, 1727, 3199, 2648, 1017,  732,  608, 1787,  411, 3124, 1758,
        1223,  652, 2777, 1015, 2036, 1491, 3047, 1785,  516, 3321, 3009, 2663, 1711, 2167,  126, 1469,
        2476, 3239, 3058,  830,  107, 1908, 3082, 2378, 2931,  961, 1821, 2604,  448, 2264,  677, 2054,
        2226,  430,  555,  843, 2078,  871, 1550,  105,  422,  587,  177, 3094, 3038, 2869, 1574, 1653,
        3083,  778, 1159, 3182, 2552, 1483, 2727, 1119, 1739,  644, 2457,  349,  418,  329, 3173, 3254,
        817, 1097,  603,  610, 1322, 2044, 1864, 384, 2114, 3193,  1218, 1994, 2455,  220, 2142, 1670,
        2144, 1799, 2051,  794, 1819, 2475, 2459, 478, 3221, 3021,   996,  991,  958, 1869, 1522, 1628
};

int16_t montgomery_reduce(int32_t a)
{
    int32_t t;
    int16_t u;

    u = (int16_t) a*QINV;
    t = (int32_t)u*KYBER_Q;
    t = a - t;
    t >>= 16;
    return (int16_t) t;
}

int16_t barrett_reduce(int16_t a) {
    int16_t t;
    const int16_t v = ((1U << 26) + KYBER_Q/2)/KYBER_Q;

    t  = (int32_t)v*a >> 26;
    t *= KYBER_Q;
    return a - t;
}
void poly_reduce(poly *r)
{
    unsigned int i;
    for(i=0;i<KYBER_N;i++) {
        r->coeffs[i] = barrett_reduce(r->coeffs[i]);
    }

}

static int16_t fqmul(int16_t a, int16_t b) {
    return montgomery_reduce((int32_t)a*b);
}
void basemul(int16_t r[2],
             const int16_t a[2],
             const int16_t b[2],
             int16_t zeta)
{
    r[0]  = fqmul(a[1], b[1]);
    r[0]  = fqmul(r[0], zeta);
    r[0] += fqmul(a[0], b[0]);

    r[1]  = fqmul(a[0], b[1]);
    r[1] += fqmul(a[1], b[0]);
}

void poly_basemul_montgomery(poly *r,  const poly *a, const poly *b)
{
    unsigned int i;
    for(i=0;i<KYBER_N/4;i++) {
        basemul(&r->coeffs[4*i], &a->coeffs[4*i], &b->coeffs[4*i], zetas[64+i]);
        basemul(&r->coeffs[4*i+2], &a->coeffs[4*i+2], &b->coeffs[4*i+2],-zetas[64+i]);
    }
    poly_reduce(r);
}

int main(){
return 0;
}



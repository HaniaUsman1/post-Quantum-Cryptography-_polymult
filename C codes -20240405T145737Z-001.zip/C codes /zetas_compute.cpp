#include <iostream>
#include <stdint.h>

#define MONT   2285        // Montgomery factor R = 2^16 mod q
#define QINV    62209      // Inverse mod %  R  =  q^-1 mod 2^16
#define KYBER_Q  3329      // Modulus q 



int16_t montgomery_reduce(int32_t a)
{
    int32_t t;
    int16_t u;

    u = a*QINV;
    t = (int32_t)u*KYBER_Q;
    t = a - t;
    t >>= 16;
    return t;
}

static int16_t fqmul(int16_t a, int16_t b) {
    return montgomery_reduce((int32_t)a*b);
}


int16_t barrett_reduce(int16_t a) {
    int16_t t;
    const int16_t v = ((1U << 26) + KYBER_Q/2)/KYBER_Q;

    t  = (int32_t)v*a >> 26;
    t *= KYBER_Q;
    return a - t;
}


#define KYBER_ROOT_OF_UNITY  17


static const uint16_t tree[128] = {
              0, 64, 32, 96, 16, 80, 48, 112, 8, 72, 40, 104, 24, 88, 56, 120,
              4, 68, 36, 100, 20, 84, 52, 116, 12, 76, 44, 108, 28, 92, 60, 124,
              2, 66, 34, 98, 18, 82, 50, 114, 10, 74, 42, 106, 26, 90, 58, 122,
              6, 70, 38, 102, 22, 86, 54, 118, 14, 78, 46, 110, 30, 94, 62, 126,
              1, 65, 33, 97, 17, 81, 49, 113, 9, 73, 41, 105, 25, 89, 57, 121,
              5, 69, 37, 101, 21, 85, 53, 117, 13, 77, 45, 109, 29, 93, 61, 125,
              3, 67, 35, 99, 19, 83, 51, 115, 11, 75, 43, 107, 27, 91, 59, 123,
              7, 71, 39, 103, 23, 87, 55, 119, 15, 79, 47, 111, 31, 95, 63, 127
};


void zet() {
    unsigned int i;
    int16_t tmp[128];
     uint16_t zetas[128];

    tmp[0] = MONT;
    for (i = 1; i < 128; ++i){
        tmp[i] = fqmul(tmp[i - 1], KYBER_ROOT_OF_UNITY * MONT % KYBER_Q);
    std::cout<<barrett_reduce(tmp[i])<<" ";}

    //Arranging zetas in 128-degree cooley tukey tree
std::cout<<" \n\n Arranging zetas in 128-degree cooley tukey tree \n\n ";
    for (i = 0; i < 128; ++i){
        zetas[i] = tmp[tree[i]];
       std::cout<<barrett_reduce(zetas[i])<<" ";
       }
}



void inv_zet(){

    int16_t  tm[128]= {
           2285, 2226, 1223, 817, 573, 3083, 2476, 2144, 3158, 422, 516, 2114, 2648, 1739, 2931, 3221, 1493, 2078, 2036, 1322, 2500,
           2552, 107, 1819, 962, 3038, 1711, 2455, 1787, 418, 448, 958, 2970, 555, 2777, 603, 264, 1159, 3058, 2051, 1577, 177, 3009,
           1218, 732, 2457, 1821, 996, 287, 1550, 3047, 1864, 1727, 2727, 3082, 2459, 1855, 1574, 126, 2142, 3124, 3173, 677, 1522,
           2571, 430, 652, 1097, 2004, 778, 3239, 1799, 622, 587, 3321, 3193, 1017, 644, 961, 3021, 1422, 871, 1491, 2044, 1458,
           1483, 1908, 2475, 2127, 2869, 2167, 220, 411, 329, 2264, 1869, 1812, 843, 1015, 610, 383, 3182, 830, 794, 182, 3094, 2663,
           1994, 608, 349, 2604, 991, 202, 105, 1785, 384, 3199, 1119, 2378, 478, 1468, 1653, 1469, 1670, 1758, 3254, 2054, 1628
    };
unsigned int i,j;
j=0;
int16_t z_inv[128];
int16_t  zetas_inv[128];
    for ( i = 127; i > 0; i--) {
        zetas_inv[j]=-tm[i];
        std::cout<<barrett_reduce(zetas_inv[j])<<" ";
j++;
    }
    zetas_inv[127] = MONT * (MONT * (KYBER_Q - 1) * ((KYBER_Q - 1) / 128) % KYBER_Q) % KYBER_Q;
    std::cout<<zetas_inv[127];

    //Arranging inverse zetas in 128 degree cooley-Tukey tree
    std::cout<<" \n\nArranging inverse zetas in 128 degree cooley-Tukey tree\n\n ";
        for (i = 0; i < 128; ++i){
            z_inv[i] = zetas_inv[tree[i]];
           std::cout<<barrett_reduce(z_inv[i])<<" ";
           }
}


int main()
{
    std::cout << " Zetas : " << std::endl;
    zet();
    std::cout<<" \n\n inverse zetas:  \n\n ";
    inv_zet();

    return 0;
}

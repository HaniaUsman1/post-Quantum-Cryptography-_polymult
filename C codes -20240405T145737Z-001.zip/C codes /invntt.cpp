#include <stdint.h>
#define KYBER_Q 3329
#define QINV 62209
const int16_t zetas_inv[128] = {
        1701, 1807, 1460, 2371, 2338, 2333, 308, 108, 2851, 870, 854, 1510, 2535,
        1278, 1530, 1185, 1659, 1187, 3109, 874, 1335, 2111, 136, 1215, 2945, 1465,
        1285, 2007, 2719, 2726, 2232, 2512, 75, 156, 3000, 2911, 2980, 872, 2685,
        1590, 2210, 602, 1846, 777, 147, 2170, 2551, 246, 1676, 1755, 460, 291, 235,
        3152, 2742, 2907, 3224, 1779, 2458, 1251, 2486, 2774, 2899, 1103, 1275, 2652,
        1065, 2881, 725, 1508, 2368, 398, 951, 247, 1421, 3222, 2499, 271, 90, 853,
        1860, 3203, 1162, 1618, 666, 320, 8, 2813, 1544, 282, 1838, 1293, 2314, 552,
        2677, 2106, 1571, 205, 2918, 1542, 2721, 2597, 2312, 681, 130, 1602, 1871,
        829, 2946, 3065, 1325, 2756, 1861, 1474, 1202, 2367, 3147, 1752, 2707, 171,
        3127, 3042, 1907, 1836, 1517, 359, 758, 1441
};
int16_t montgomery_reduce(int32_t a)
{
    int32_t t;
    int16_t u;

    u = (int16_t) a*QINV;
    t = (int32_t)u*KYBER_Q;
    t = a - t;
    t >>= 16;
    return (int16_t) t;
}

int16_t barrett_reduce(int16_t a) {
    int16_t t;
    const int16_t v = ((1U << 26) + KYBER_Q/2)/KYBER_Q;

    t  = (int32_t)v*a >> 26;
    t *= KYBER_Q;
    return a - t;
}

static int16_t fqmul(int16_t a, int16_t b) {
    return montgomery_reduce((int32_t)a*b);
}
void invntt(int16_t r[256]) {
    unsigned int start, len, j, k;
    int16_t t, zeta;
    k = 0;
    for(len = 2; len <= 128; len <<= 1) {
        for(start = 0; start < 256; start = j + len) {
            zeta = zetas_inv[k++];
            for(j = start; j < start + len; ++j) {
                t = r[j];
                r[j] = barrett_reduce(t + r[j + len]);
                r[j + len] = t - r[j + len];
                r[j + len] = fqmul(zeta, r[j + len]);
            }
        }
    }
    for(j = 0; j < 256; ++j){
        r[j] =fqmul(r[j] ,zetas_inv[127]);
        r[j]= montgomery_reduce(r[j]);
        r[j]= barrett_reduce(r[j]);
    }
}

int main(){

    return 0;
}